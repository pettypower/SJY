To import one of these xml Rules files: 

Run Beyond Compare's Folder Viewer and select Tools | Import Settings. 

In Select import file, enter the name of the rules file you downloaded and click Next. 

Verify that the new rule(s) are checked in the Pick rules to import list and click Next, then Finish. 